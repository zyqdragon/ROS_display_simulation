# UR5 joint position controller package with ros_control

A description on how to use this package can be found in the following blog post: 

https://roboticscasual.com/ros-tutorial-control-the-ur5-robot-with-ros_control-tuning-a-pid-controller/
