#!/usr/bin/env python
import rospy
from std_msgs.msg import Float64
 
def publisher_node():
    # 初始化节点
    rospy.init_node('cmd_float64_publisher', anonymous=True)
    # 创建发布者
    pub = rospy.Publisher('wrist_1_joint_position_controller/command', Float64, queue_size=10)
    # 设置循环的频率
    rate = rospy.Rate(20) # 10hz
    # 消息实例
    msg = Float64() 
    # 循环发布消息
    cnt=1.8
    flag_cnt=True
    while not rospy.is_shutdown():
        # 修改消息数据
        # msg.data = rospy.Time.now().to_nsec() / 1e9  # 发布当前时间（作为小数） 
    
        msg.data = cnt
        if flag_cnt==True:
            cnt=cnt+0.01
            if msg.data>=3.12:
                flag_cnt=~flag_cnt
        else:
            cnt=cnt-0.01
            if msg.data<=-3.12:
                flag_cnt=~flag_cnt
 
        print("---------msg.data=",msg.data)
        # 发布消息
        pub.publish(msg) 
        # 等待rate定义的时间
        rate.sleep()
 
if __name__ == '__main__':
    try:
        publisher_node()
    except rospy.ROSInterruptException:
        pass